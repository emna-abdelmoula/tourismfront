import { Component, ViewEncapsulation  } from '@angular/core';

@Component({
  selector: 'app-landingpage',
  templateUrl: './landingpage.component.html',
  styleUrls: ['./landingpage.component.css'],
  encapsulation: ViewEncapsulation.None  // Emulated is the default

})
export class LandingpageComponent {

}
